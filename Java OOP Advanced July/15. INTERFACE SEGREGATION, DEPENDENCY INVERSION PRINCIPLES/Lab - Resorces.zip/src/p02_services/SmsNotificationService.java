package p02_services;

public class SmsNotificationService {

    public void sendNotification() {

    }

    public boolean isActive() {
        return false;
    }
}
