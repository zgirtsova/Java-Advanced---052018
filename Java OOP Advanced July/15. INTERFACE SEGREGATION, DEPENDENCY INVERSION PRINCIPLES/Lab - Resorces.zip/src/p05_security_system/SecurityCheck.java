package p05_security_system;

public abstract class SecurityCheck {

    public abstract boolean validateUser();
}
