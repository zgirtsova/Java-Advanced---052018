package app;

import app.constants.Constants;
import app.contracts.ComicCharacter;
import app.controllers.Engine;
import app.entities.antiheroes.Titan;
import app.entities.heroes.DCHero;

import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    public static void main(String[] args) {

        Set<ComicCharacter> set = new HashSet<>();



    }
}
